<?php
/**
 * WordPress基础配置文件。
 *
 * 这个文件被安装程序用于自动生成wp-config.php配置文件，
 * 您可以不使用网站，您需要手动复制这个文件，
 * 并重命名为“wp-config.php”，然后填入相关信息。
 *
 * 本文件包含以下配置选项：
 *
 * * MySQL设置
 * * 密钥
 * * 数据库表名前缀
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/zh-cn:%E7%BC%96%E8%BE%91_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL 设置 - 具体信息来自您正在使用的主机 ** //
/** WordPress数据库的名称 */
define('DB_NAME', 'ec');

/** MySQL数据库用户名 */
define('DB_USER', 'ec');

/** MySQL数据库密码 */
define('DB_PASSWORD', 'eternalcenter');

/** MySQL主机 */
define('DB_HOST', '127.0.0.1');

/** 创建数据表时默认的文字编码 */
define('DB_CHARSET', 'utf8mb4');

/** 数据库整理类型。如不确定请勿更改 */
define('DB_COLLATE', '');

/**#@+
 * 身份认证密钥与盐。
 *
 * 修改为任意独一无二的字串！
 * 或者直接访问{@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org密钥生成服务}
 * 任何修改都会导致所有cookies失效，所有用户将必须重新登录。
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'g]|Z0D$Bwti^6cPlBT29yF}.yf!!n#4B*:u_k0To**b9qEC!Y|b*30J18z}GyIWL');
define('SECURE_AUTH_KEY',  'B ?G3rkHQXDEDP%`y}5fZ1e9sh~XpC^w-1BZ1&%rB kx181%Oh:<CfCbXiz=Cm}Q');
define('LOGGED_IN_KEY',    'D{J|(g<8qRZ?c!Y$v6hPT!dBPu$Nlj}::c@jADYo-L^pP&P~vGIY5U#<cL_ng<`J');
define('NONCE_KEY',        'eW5iN+eWf0~~mH{3boK(E(M#dk)J8s.8FAE221vi3jsyjYXZwok>n)VJnq~4Tx.a');
define('AUTH_SALT',        '&@7!;+ZJCn9 M>m-bXEp4.+7V_~h?|OA9]#8Fai&Q7B^!mC<I0;T0{(ZI4WzE#p:');
define('SECURE_AUTH_SALT', '!lS8MU@(=Y@#,)ZH:T*QW}11Fdc.&;J1oT.[NED2k5XOFdY5O=0@1;~Jzg0=ypwR');
define('LOGGED_IN_SALT',   '*R%Fc@5t[%3= ]pl$BsZKaualgRN`0oc{Z0>bmuAS$~}&DUhT)L-K{O}JxI5l, 9');
define('NONCE_SALT',       'fq~]#oaZv|n+mi%9hiy#M/l?X%kb{QoKf:H 1#VY7*G8~}b]%8.<;U.Ox;b,2%Zk');

/**#@-*/

/**
 * WordPress数据表前缀。
 *
 * 如果您有在同一数据库内安装多个WordPress的需求，请为每个WordPress设置
 * 不同的数据表前缀。前缀名只能为数字、字母加下划线。
 */
$table_prefix  = 'ec_';

/**
 * 开发者专用：WordPress调试模式。
 *
 * 将这个值改为true，WordPress将显示所有用于开发的提示。
 * 强烈建议插件开发者在开发环境中启用WP_DEBUG。
 *
 * 要获取其他能用于调试的信息，请访问Codex。
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* 好了！请不要再继续编辑。请保存本文件。使用愉快！ */

/** WordPress目录的绝对路径。 */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** 设置WordPress变量和包含文件。 */
require_once(ABSPATH . 'wp-settings.php');

define("FS_METHOD", "direct");
define("FS_CHMOD_DIR", 0755);
define("FS_CHMOD_FILE", 0755);

//Disable File Edits
define('DISALLOW_FILE_EDIT', true);


?>
